def playback():
    string_sentence=input('')
    string=string_sentence.replace(' ','...')
    print(string)
print(playback())


