def indoor():
    string=input('')
    if string.upper():
        return string.lower()
print(indoor())


