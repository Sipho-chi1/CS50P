def convert():
    string=input('')
    string=string.replace(':)','🙂')
    string=string.replace(':(','🙁')
    print(string)
convert()
