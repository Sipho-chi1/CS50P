def einstein():
    mass=int(input('enter mass in kg:'))
    speed_of_light=300000000
    energy=mass*speed_of_light**2
    print('energy in joules',energy)
einstein()
